# Secrets Directory

Put any *secret* file in this directory and make sure that you include it in the `.gitignore` file.
